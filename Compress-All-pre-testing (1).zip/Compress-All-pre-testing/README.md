## Compress-All

Building Basic Extension
